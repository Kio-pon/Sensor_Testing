#include "MecanumDrive.h"
#include "Config.h"

void initMotors() {
  uint8_t dirPins[] = {FL_IN1, FL_IN2, RL_IN3, RL_IN4, FR_IN1, FR_IN2, RR_IN3, RR_IN4};
  for (uint8_t i = 0; i < 8; i++) {
    pinMode(dirPins[i], OUTPUT);
    digitalWrite(dirPins[i], LOW);
  }

  pinMode(FL_ENA, OUTPUT);
  pinMode(RL_ENB, OUTPUT);
  pinMode(FR_ENA, OUTPUT);
  pinMode(RR_ENB, OUTPUT);
}

void driveForward(int leftPWM, int rightPWM) {
  digitalWrite(FL_IN1, HIGH); digitalWrite(FL_IN2, LOW); analogWrite(FL_ENA, leftPWM);
  digitalWrite(RL_IN3, HIGH); digitalWrite(RL_IN4, LOW); analogWrite(RL_ENB, leftPWM);
  digitalWrite(FR_IN1, HIGH); digitalWrite(FR_IN2, LOW); analogWrite(FR_ENA, rightPWM);
  digitalWrite(RR_IN3, HIGH); digitalWrite(RR_IN4, LOW); analogWrite(RR_ENB, rightPWM);
}

void stopAll() {
  analogWrite(FL_ENA, 0); analogWrite(RL_ENB, 0);
  analogWrite(FR_ENA, 0); analogWrite(RR_ENB, 0);
  digitalWrite(FL_IN1, LOW); digitalWrite(FL_IN2, LOW);
  digitalWrite(RL_IN3, LOW); digitalWrite(RL_IN4, LOW);
  digitalWrite(FR_IN1, LOW); digitalWrite(FR_IN2, LOW);
  digitalWrite(RR_IN3, LOW); digitalWrite(RR_IN4, LOW);
}

void strafeRight(int pwm) {
  digitalWrite(FL_IN1, HIGH); digitalWrite(FL_IN2, LOW);  analogWrite(FL_ENA, pwm);
  digitalWrite(RL_IN3, LOW);  digitalWrite(RL_IN4, HIGH); analogWrite(RL_ENB, pwm);
  digitalWrite(FR_IN1, LOW);  digitalWrite(FR_IN2, HIGH); analogWrite(FR_ENA, pwm);
  digitalWrite(RR_IN3, HIGH); digitalWrite(RR_IN4, LOW);  analogWrite(RR_ENB, pwm);
}

void strafeLeft(int pwm) {
  digitalWrite(FL_IN1, LOW);  digitalWrite(FL_IN2, HIGH); analogWrite(FL_ENA, pwm);
  digitalWrite(RL_IN3, HIGH); digitalWrite(RL_IN4, LOW);  analogWrite(RL_ENB, pwm);
  digitalWrite(FR_IN1, HIGH); digitalWrite(FR_IN2, LOW);  analogWrite(FR_ENA, pwm);
  digitalWrite(RR_IN3, LOW);  digitalWrite(RR_IN4, HIGH); analogWrite(RR_ENB, pwm);
}

void rotateClockwise(int pwm) {
  digitalWrite(FL_IN1, HIGH); digitalWrite(FL_IN2, LOW);  analogWrite(FL_ENA, pwm);
  digitalWrite(RL_IN3, HIGH); digitalWrite(RL_IN4, LOW);  analogWrite(RL_ENB, pwm);
  digitalWrite(FR_IN1, LOW);  digitalWrite(FR_IN2, HIGH); analogWrite(FR_ENA, pwm);
  digitalWrite(RR_IN3, LOW);  digitalWrite(RR_IN4, HIGH); analogWrite(RR_ENB, pwm);
}

void rotateCounterClockwise(int pwm) {
  digitalWrite(FL_IN1, LOW);  digitalWrite(FL_IN2, HIGH); analogWrite(FL_ENA, pwm);
  digitalWrite(RL_IN3, LOW);  digitalWrite(RL_IN4, HIGH); analogWrite(RL_ENB, pwm);
  digitalWrite(FR_IN1, HIGH); digitalWrite(FR_IN2, LOW);  analogWrite(FR_ENA, pwm);
  digitalWrite(RR_IN3, HIGH); digitalWrite(RR_IN4, LOW);  analogWrite(RR_ENB, pwm);
}
