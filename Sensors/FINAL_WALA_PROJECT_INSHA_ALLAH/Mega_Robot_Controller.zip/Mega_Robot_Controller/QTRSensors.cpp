#include "QTRSensors.h"
#include "Config.h"

const uint8_t QTR_PINS[8] = {A0, A1, A2, A3, A4, A5, A6, A7};

void initQTR() {
  for (int i=0; i<8; i++) {
    pinMode(QTR_PINS[i], INPUT);
  }
}

uint16_t readQTR(uint8_t pin) {
  uint32_t sum = 0;
  for (uint8_t i = 0; i < 4; i++) {
    sum += analogRead(pin);
  }
  return (uint16_t)(sum >> 2); 
}

// Proper ADC Line Position Calculation (Standard 0-7000 output)
// This matches your STM32 configuration where LINE_CENTER is 3500.
float getLinePosition(float lastPosition) {
  uint32_t weightedSum = 0;
  uint32_t sum = 0;
  bool onLine = false;

  for (uint8_t i = 0; i < 8; i++) {
    uint16_t val = readQTR(QTR_PINS[i]);
    
    // In Arduino, 10-bit ADC goes 0-1023. 
    // Assuming low value = Black line (high reflection of white floor)
    // We invert it so the line has the highest weight for the math.
    int32_t weight = 1023 - val; 
    
    // Only consider it 'on the line' if the inverted value breaks our threshold.
    // BLACK_THRESHOLD is around 750. Inverted threshold is (1023 - 750) = 273.
    if (weight > (1023 - BLACK_THRESHOLD)) {
      onLine = true;
    } else {
      weight = 0; // Ignore noise from the white floor
    }

    weightedSum += (weight * i * 1000);
    sum += weight;
  }

  if (!onLine || sum == 0) {
    // Lost line fallback: If we were previously left of center (3500), 
    // push hard left (0). If right, push hard right (7000).
    return (lastPosition < LINE_CENTER) ? 0.0f : 7000.0f; 
  }
  
  return (float)weightedSum / (float)sum;
}
