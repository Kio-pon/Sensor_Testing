#ifndef QTR_SENSORS_H
#define QTR_SENSORS_H

#include <Arduino.h>

void initQTR();
float getLinePosition(float lastError);

#endif
